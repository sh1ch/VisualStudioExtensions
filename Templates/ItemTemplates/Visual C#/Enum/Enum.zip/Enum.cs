﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace $rootnamespace$;

/// <summary>
/// <see cref="$safeitemname$"/> 列挙型は、＊を示します。
/// </summary>
public enum $safeitemname$
{
    
}
