﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace $rootnamespace$
{
    /// <summary>
    /// $safeitemname$ クラスは、＊＊＊をサポートするためのクラスです。
    /// </summary>
    public class $safeitemname$
    {
        #region Fields
        
        #endregion
        
        #region Properties
        
        #endregion

        #region Initializes

        /// <summary>
        /// <see cref="$safeitemname$"/> クラスの新しいインスタンスを初期化します。
        /// </summary>
        public $safeitemname$(){  }
        
        #endregion

        #region Events
        
        #endregion

        #region Public Methods
        
        #endregion
        
        #region Private Methods
        
        #endregion
    }
}
