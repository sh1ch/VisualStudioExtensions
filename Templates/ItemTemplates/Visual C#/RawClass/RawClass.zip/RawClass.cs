﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace $rootnamespace$;

/// <summary>
/// <see cref="$safeitemname$"/> クラスは、＊です。
/// </summary>
public class $safeitemname$
{
    /// <summary>
    /// <see cref="$safeitemname$"/> クラスの新しいインスタンスを初期化します。
    /// </summary>
    public $safeitemname$()
    {
        
    }
}
