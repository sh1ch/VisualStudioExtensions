﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace $rootnamespace$
{
    /// <summary>
    /// $safeitemname$ インターフェースは、値型・クラス型で実装する＊＊＊を目的とするメソッド・プロパティを定義します。
    /// </summary>
    public interface $safeitemname$
    {
        
    }
}
