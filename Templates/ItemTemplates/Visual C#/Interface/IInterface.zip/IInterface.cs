﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace $rootnamespace$;

/// <summary>
/// <see cref="$safeitemname$"/> インターフェースは、＊に関するパラメーターを定義します。
/// </summary>
public interface $safeitemname$
{
}
