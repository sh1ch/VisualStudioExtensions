﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace $rootnamespace$
{
    /// <summary>
    /// <see cref="$safeitemname$"/> クラスは、＊＊＊をサポートするためのクラスです。
    /// </summary>
    public class $safeitemname$ : INotifyPropertyChanged
    {
        #region Fields
        
        #endregion

        #region Properties
        
        #endregion

        #region Initializes

        /// <summary>
        /// <see cref="$safeitemname$"/> クラスの新しいインスタンスを初期化します。
        /// </summary>
        public $safeitemname$() 
        {
        	
        }
        
        #endregion

        #region Events

        public event PropertyChangedEventHandler PropertyChanged;
        
        #endregion

        #region Public Methods
        
        #endregion

        #region Private Methods
        
        #endregion
    }
}
