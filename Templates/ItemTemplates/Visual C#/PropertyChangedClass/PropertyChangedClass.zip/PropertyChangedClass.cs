﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace $rootnamespace$;

/// <summary>
/// <see cref="$safeitemname$"/> クラスは、＊です。
/// </summary>
public class $safeitemname$ : INotifyPropertyChanged
{
    public event PropertyChangedEventHandler PropertyChanged;

    /// <summary>
    /// <see cref="$safeitemname$"/> クラスの新しいインスタンスを初期化します。
    /// </summary>
    public $safeitemname$() 
    {
        
    }
}
